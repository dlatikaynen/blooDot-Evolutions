package oy.sarjakuvat.flamingin.bde.gles

import oy.sarjakuvat.flamingin.bde.MainActivity.Companion.gpuSourceTextureVertexShader
import oy.sarjakuvat.flamingin.bde.MainActivity.Companion.gpuSourceTextureFragmentShader2d
import oy.sarjakuvat.flamingin.bde.MainActivity.Companion.gpuSourceTextureFragmentShaderExternal
import oy.sarjakuvat.flamingin.bde.MainActivity.Companion.gpuSourceTextureFragmentShaderExternalBw
import oy.sarjakuvat.flamingin.bde.MainActivity.Companion.gpuSourceTextureFragmentShaderConvolutions
import oy.sarjakuvat.flamingin.bde.gles.GlUtil.createProgram
import oy.sarjakuvat.flamingin.bde.gles.GlUtil.checkLocation
import oy.sarjakuvat.flamingin.bde.gles.GlUtil.checkGlError
import android.opengl.GLES20
import android.opengl.GLES11Ext
import android.util.Log
import java.lang.RuntimeException
import java.nio.FloatBuffer

class Texture2dProgram(programType: ProgramType) {
    private var mProgramHandle = 0
    private val muMVPMatrixLoc: Int
    private val muTexMatrixLoc: Int
    private var muKernelLoc: Int
    private var muTexOffsetLoc = 0
    private var muColorAdjustLoc = 0
    private val maPositionLoc: Int
    private val maTextureCoordLoc: Int
    private var mTextureTarget = 0
    private val mKernel = FloatArray(KERNEL_SIZE)
    private lateinit var mTexOffset: FloatArray
    private var mColorAdjust = 0f

    enum class ProgramType {
        TEXTURE_2D, TEXTURE_EXT, TEXTURE_EXT_BW, TEXTURE_EXT_FILT
    }

    fun createTextureObject(): Int {
        val textures = IntArray(1)
        GLES20.glGenTextures(1, textures, 0)
        checkGlError("glGenTextures")
        val texId = textures[0]
        GLES20.glBindTexture(mTextureTarget, texId)
        checkGlError("glBindTexture $texId")
        GLES20.glTexParameterf(
            GLES11Ext.GL_TEXTURE_EXTERNAL_OES,
            GLES20.GL_TEXTURE_MIN_FILTER,
            GLES20.GL_NEAREST.toFloat()
        )

        GLES20.glTexParameterf(
            GLES11Ext.GL_TEXTURE_EXTERNAL_OES,
            GLES20.GL_TEXTURE_MAG_FILTER,
            GLES20.GL_LINEAR.toFloat()
        )

        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE)
        checkGlError("glTexParameter")
        return texId
    }

    private fun setKernel(
        values: FloatArray,
        @Suppress("SameParameterValue")  colorAdj: Float
    ) {
        require(values.size == KERNEL_SIZE) {
            "Convolution kernel size is ${values.size} where it should be $KERNEL_SIZE"
        }

        System.arraycopy(values, 0, mKernel, 0, KERNEL_SIZE)
        mColorAdjust = colorAdj
    }

    private fun setTexSize(
        @Suppress("SameParameterValue") width: Int,
        @Suppress("SameParameterValue") height: Int
    ) {
        val rw = 1.0f / width
        val rh = 1.0f / height
        mTexOffset = floatArrayOf(
            -rw, -rh, 0f, -rh, rw, -rh,
            -rw, 0f, 0f, 0f, rw, 0f,
            -rw, rh, 0f, rh, rw, rh
        )
    }

    fun draw(
        mvpMatrix: FloatArray?,
        vertexBuffer: FloatBuffer?,
        firstVertex: Int,
        vertexCount: Int,
        coordsPerVertex: Int,
        vertexStride: Int,
        texMatrix: FloatArray?,
        texBuffer: FloatBuffer?,
        textureId: Int,
        texStride: Int
    ) {
        checkGlError("draw::begin")
        GLES20.glUseProgram(mProgramHandle)
        checkGlError("glUseProgram")
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
        GLES20.glBindTexture(mTextureTarget, textureId)
        GLES20.glUniformMatrix4fv(muMVPMatrixLoc, 1, false, mvpMatrix, 0)
        checkGlError("glUniformMatrix4fv")
        GLES20.glUniformMatrix4fv(muTexMatrixLoc, 1, false, texMatrix, 0)
        checkGlError("glUniformMatrix4fv")
        GLES20.glEnableVertexAttribArray(maPositionLoc)
        checkGlError("glEnableVertexAttribArray")
        GLES20.glVertexAttribPointer(
            maPositionLoc, coordsPerVertex,
            GLES20.GL_FLOAT, false, vertexStride, vertexBuffer
        )

        checkGlError("glVertexAttribPointer")
        GLES20.glEnableVertexAttribArray(maTextureCoordLoc)
        checkGlError("glEnableVertexAttribArray")
        GLES20.glVertexAttribPointer(
            maTextureCoordLoc, 2,
            GLES20.GL_FLOAT, false, texStride, texBuffer
        )

        checkGlError("glVertexAttribPointer")
        if (muKernelLoc >= 0) {
            GLES20.glUniform1fv(muKernelLoc, KERNEL_SIZE, mKernel, 0)
            GLES20.glUniform2fv(muTexOffsetLoc, KERNEL_SIZE, mTexOffset, 0)
            GLES20.glUniform1f(muColorAdjustLoc, mColorAdjust)
        }

        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, firstVertex, vertexCount)
        checkGlError("glDrawArrays")

        GLES20.glDisableVertexAttribArray(maPositionLoc)
        GLES20.glDisableVertexAttribArray(maTextureCoordLoc)
        GLES20.glBindTexture(mTextureTarget, 0)
        GLES20.glUseProgram(0)
    }

    fun release() {
        Log.d(TAG, "Deleting GPU shader program $mProgramHandle")
        GLES20.glDeleteProgram(mProgramHandle)
        checkGlError("glDeleteProgram")
        mProgramHandle = -1
    }

    init {
        when (programType) {
            ProgramType.TEXTURE_2D -> {
                mTextureTarget = GLES20.GL_TEXTURE_2D
                mProgramHandle = createProgram(VERTEX_SHADER, FRAGMENT_SHADER_2D)
            }
            ProgramType.TEXTURE_EXT -> {
                mTextureTarget = GLES11Ext.GL_TEXTURE_EXTERNAL_OES
                mProgramHandle = createProgram(VERTEX_SHADER, FRAGMENT_SHADER_EXT)
            }
            ProgramType.TEXTURE_EXT_BW -> {
                mTextureTarget = GLES11Ext.GL_TEXTURE_EXTERNAL_OES
                mProgramHandle = createProgram(VERTEX_SHADER, FRAGMENT_SHADER_EXT_BW)
            }
            ProgramType.TEXTURE_EXT_FILT -> {
                mTextureTarget = GLES11Ext.GL_TEXTURE_EXTERNAL_OES
                mProgramHandle = createProgram(VERTEX_SHADER, FRAGMENT_SHADER_EXT_FILT)
            }
        }

        if (mProgramHandle == 0) {
            throw RuntimeException("Failed to create GPU shader program")
        }

        Log.d(TAG, "Created GPU $programType shader program $mProgramHandle")
        maPositionLoc = GLES20.glGetAttribLocation(mProgramHandle, "aPosition")
        checkLocation(maPositionLoc, "aPosition")
        maTextureCoordLoc = GLES20.glGetAttribLocation(mProgramHandle, "aTextureCoord")
        checkLocation(maTextureCoordLoc, "aTextureCoord")
        muMVPMatrixLoc = GLES20.glGetUniformLocation(mProgramHandle, "uMVPMatrix")
        checkLocation(muMVPMatrixLoc, "uMVPMatrix")
        muTexMatrixLoc = GLES20.glGetUniformLocation(mProgramHandle, "uTexMatrix")
        checkLocation(muTexMatrixLoc, "uTexMatrix")
        muKernelLoc = GLES20.glGetUniformLocation(mProgramHandle, "uKernel")
        if (muKernelLoc < 0) {
            muKernelLoc = -1
            muTexOffsetLoc = -1
            muColorAdjustLoc = -1
        } else {
            muTexOffsetLoc = GLES20.glGetUniformLocation(mProgramHandle, "uTexOffset")
            checkLocation(muTexOffsetLoc, "uTexOffset")
            muColorAdjustLoc = GLES20.glGetUniformLocation(mProgramHandle, "uColorAdjust")
            checkLocation(muColorAdjustLoc, "uColorAdjust")
            setKernel(floatArrayOf(0f, 0f, 0f, 0f, 1f, 0f, 0f, 0f, 0f), 0f)
            setTexSize(256, 256)
        }
    }

    companion object {
        private val TAG = GlUtil.TAG
        private val VERTEX_SHADER = gpuSourceTextureVertexShader
        private val FRAGMENT_SHADER_2D = gpuSourceTextureFragmentShader2d
        private val FRAGMENT_SHADER_EXT = gpuSourceTextureFragmentShaderExternal
        private val FRAGMENT_SHADER_EXT_BW = gpuSourceTextureFragmentShaderExternalBw
        const val KERNEL_SIZE = 9
        private val FRAGMENT_SHADER_EXT_FILT = gpuSourceTextureFragmentShaderConvolutions
    }
}
