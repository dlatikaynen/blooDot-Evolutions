package oy.sarjakuvat.flamingin.bde.gles

import android.opengl.EGL14
import kotlin.Throws
import android.opengl.GLES20
import android.graphics.Bitmap
import android.util.Log
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.lang.RuntimeException
import java.nio.ByteBuffer
import java.nio.ByteOrder

open class EglSurfaceBase protected constructor(
    eglCore: EglCore
) {
    @Suppress("UNNECESSARY_LATEINIT", "JoinDeclarationAndAssignment")
    protected lateinit var mEglCore: EglCore

    private var mEGLSurface = EGL14.EGL_NO_SURFACE
    private var mWidth = -1
    private var mHeight = -1

    init {
        mEglCore = eglCore
    }

    fun createWindowSurface(surface: Any?) {
        check(!(mEGLSurface !== EGL14.EGL_NO_SURFACE)) {
            "Attempt to create surface twice"
        }

        mEGLSurface = mEglCore.createWindowSurface(surface!!)
    }

    fun createOffscreenSurface(width: Int, height: Int) {
        check(!(mEGLSurface !== EGL14.EGL_NO_SURFACE)) {
            "Attempt to create offscreen surface twice"
        }

        mEGLSurface = mEglCore.createOffscreenSurface(width, height)
        mWidth = width
        mHeight = height
    }

    val width: Int
        get() = if (mWidth < 0) {
            mEglCore.querySurface(mEGLSurface, EGL14.EGL_WIDTH)
        } else {
            mWidth
        }

    val height: Int
        get() = if (mHeight < 0) {
            mEglCore.querySurface(mEGLSurface, EGL14.EGL_HEIGHT)
        } else {
            mHeight
        }

    fun releaseEglSurface() {
        mEglCore.releaseSurface(mEGLSurface)
        mEGLSurface = EGL14.EGL_NO_SURFACE
        mHeight = -1
        mWidth = -1
    }

    fun makeCurrent() {
        mEglCore.makeCurrent(mEGLSurface)
    }

    fun makeCurrentReadFrom(readSurface: EglSurfaceBase) {
        mEglCore.makeCurrent(mEGLSurface, readSurface.mEGLSurface)
    }

    fun swapBuffers(): Boolean {
        val result = mEglCore.swapBuffers(mEGLSurface)
        if (!result) {
            Log.d(TAG, "Failed in EglCore swapBuffers call")
        }

        return result
    }

    fun setPresentationTime(nsecs: Long) {
        mEglCore.setPresentationTime(mEGLSurface, nsecs)
    }

    @Throws(IOException::class)
    fun saveFrame(file: File) {
        if (!mEglCore.isCurrent(mEGLSurface)) {
            throw RuntimeException("Egl context and surface must be current to save a frame")
        }

        val filename = file.toString()
        val width = width
        val height = height
        val buf = ByteBuffer.allocateDirect(width * height * 4)
        buf.order(ByteOrder.LITTLE_ENDIAN)
        GLES20.glReadPixels(
            0, 0, width, height,
            GLES20.GL_RGBA, GLES20.GL_UNSIGNED_BYTE, buf
        )

        GlUtil.checkGlError("glReadPixels")
        buf.rewind()
        BufferedOutputStream(FileOutputStream(filename)).use { bos ->
            val bmp = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
            bmp.copyPixelsFromBuffer(buf)
            bmp.compress(Bitmap.CompressFormat.PNG, 90, bos)
            bmp.recycle()
        }

        Log.d(TAG, "A $width by $height pixel frame was saved to $filename")
    }

    companion object {
        protected val TAG = GlUtil.TAG
    }
}
