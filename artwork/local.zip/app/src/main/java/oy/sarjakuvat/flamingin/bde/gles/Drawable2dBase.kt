package oy.sarjakuvat.flamingin.bde.gles

import java.nio.FloatBuffer

open class Drawable2dBase(shape: Prefab) {
    var vertexArray: FloatBuffer? = null
    open var texCoordArray: FloatBuffer? = null
    var vertexCount = 0
    var coordsPerVertex = 0
    var vertexStride = 0

    val texCoordStride: Int
    private val mPrefab: Prefab

    enum class Prefab {
        TRIANGLE, RECTANGLE, FULL_RECTANGLE
    }

    override fun toString(): String {
        return "[${Drawable2dBase::class.simpleName}: $mPrefab]"
    }

    companion object {
        private const val SIZEOF_FLOAT = 4
        private val TRIANGLE_COORDS = floatArrayOf(
            0.0f, 0.577350269f,  // 0 top
            -0.5f, -0.288675135f,  // 1 bottom left
            0.5f, -0.288675135f // 2 bottom right
        )

        private val TRIANGLE_TEX_COORDS = floatArrayOf(
            0.5f, 0.0f,  // 0 top center
            0.0f, 1.0f,  // 1 bottom left
            1.0f, 1.0f
        )

        private val TRIANGLE_BUF = GlUtil.createFloatBuffer(TRIANGLE_COORDS)
        private val TRIANGLE_TEX_BUF = GlUtil.createFloatBuffer(TRIANGLE_TEX_COORDS)

        private val RECTANGLE_COORDS = floatArrayOf(
            -0.5f, -0.5f,  // 0 bottom left
            0.5f, -0.5f,  // 1 bottom right
            -0.5f, 0.5f,  // 2 top left
            0.5f, 0.5f
        )

        private val RECTANGLE_TEX_COORDS = floatArrayOf(
            0.0f, 1.0f,  // 0 bottom left
            1.0f, 1.0f,  // 1 bottom right
            0.0f, 0.0f,  // 2 top left
            1.0f, 0.0f // 3 top right
        )

        private val RECTANGLE_BUF = GlUtil.createFloatBuffer(RECTANGLE_COORDS)
        private val RECTANGLE_TEX_BUF = GlUtil.createFloatBuffer(RECTANGLE_TEX_COORDS)

        private val FULL_RECTANGLE_COORDS = floatArrayOf(
            -1.0f, -1.0f,  // 0 bottom left
            1.0f, -1.0f,  // 1 bottom right
            -1.0f, 1.0f,  // 2 top left
            1.0f, 1.0f
        )

        private val FULL_RECTANGLE_TEX_COORDS = floatArrayOf(
            0.0f, 0.0f,  // 0 bottom left
            1.0f, 0.0f,  // 1 bottom right
            0.0f, 1.0f,  // 2 top left
            1.0f, 1.0f // 3 top right
        )

        private val FULL_RECTANGLE_BUF = GlUtil.createFloatBuffer(FULL_RECTANGLE_COORDS)
        private val FULL_RECTANGLE_TEX_BUF = GlUtil.createFloatBuffer(FULL_RECTANGLE_TEX_COORDS)
    }

    init {
        @Suppress("LeakingThis")
        when (shape) {
            Prefab.TRIANGLE -> {
                vertexArray = TRIANGLE_BUF
                texCoordArray = TRIANGLE_TEX_BUF
                coordsPerVertex = 2
                vertexStride = coordsPerVertex * SIZEOF_FLOAT
                vertexCount = TRIANGLE_COORDS.size / coordsPerVertex
            }
            Prefab.RECTANGLE -> {
                vertexArray = RECTANGLE_BUF
                texCoordArray = RECTANGLE_TEX_BUF
                coordsPerVertex = 2
                vertexStride = coordsPerVertex * SIZEOF_FLOAT
                vertexCount = RECTANGLE_COORDS.size / coordsPerVertex
            }
            Prefab.FULL_RECTANGLE -> {
                vertexArray = FULL_RECTANGLE_BUF
                texCoordArray = FULL_RECTANGLE_TEX_BUF
                coordsPerVertex = 2
                vertexStride = coordsPerVertex * SIZEOF_FLOAT
                vertexCount = FULL_RECTANGLE_COORDS.size / coordsPerVertex
            }
        }

        texCoordStride = 2 * SIZEOF_FLOAT
        mPrefab = shape
    }
}
