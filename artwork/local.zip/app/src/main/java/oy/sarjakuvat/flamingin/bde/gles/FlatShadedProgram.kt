package oy.sarjakuvat.flamingin.bde.gles

import oy.sarjakuvat.flamingin.bde.MainActivity.Companion.gpuSourceFlatVertexShader
import oy.sarjakuvat.flamingin.bde.MainActivity.Companion.gpuSourceFlatFragmentShader
import android.opengl.GLES20
import android.util.Log
import java.lang.RuntimeException
import java.nio.FloatBuffer

class FlatShadedProgram {
    private var mProgramHandle: Int
    private val muColorLoc: Int
    private val muMVPMatrixLoc: Int
    private val maPositionLoc: Int

    fun draw(
        mvpMatrix: FloatArray?, color: FloatArray?, vertexBuffer: FloatBuffer?,
        firstVertex: Int, vertexCount: Int, coordsPerVertex: Int, vertexStride: Int
    ) {
        GlUtil.checkGlError("draw::begin")
        GLES20.glUseProgram(mProgramHandle)
        GlUtil.checkGlError("glUseProgram")
        GLES20.glUniformMatrix4fv(muMVPMatrixLoc, 1, false, mvpMatrix, 0)
        GlUtil.checkGlError("glUniformMatrix4fv")
        GLES20.glUniform4fv(muColorLoc, 1, color, 0)
        GlUtil.checkGlError("glUniform4fv ")
        GLES20.glEnableVertexAttribArray(maPositionLoc)
        GlUtil.checkGlError("glEnableVertexAttribArray")
        GLES20.glVertexAttribPointer(
            maPositionLoc, coordsPerVertex,
            GLES20.GL_FLOAT, false, vertexStride, vertexBuffer
        )

        GlUtil.checkGlError("glVertexAttribPointer")
        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, firstVertex, vertexCount)
        GlUtil.checkGlError("glDrawArrays")
        GLES20.glDisableVertexAttribArray(maPositionLoc)
        GLES20.glUseProgram(0)
    }

    fun release() {
        GLES20.glDeleteProgram(mProgramHandle)
        GlUtil.checkGlError("glDeleteProgram")
        mProgramHandle = -1
    }

    companion object {
        private val TAG = GlUtil.TAG
        private val VERTEX_SHADER = gpuSourceFlatVertexShader
        private val FRAGMENT_SHADER = gpuSourceFlatFragmentShader
    }

    init {
        mProgramHandle = GlUtil.createProgram(VERTEX_SHADER, FRAGMENT_SHADER)
        if (mProgramHandle == 0) {
            throw RuntimeException("Failed to create GPU program")
        }

        Log.d(TAG, "GPU shader program $mProgramHandle created")
        maPositionLoc = GLES20.glGetAttribLocation(mProgramHandle, "aPosition")
        GlUtil.checkLocation(maPositionLoc, "aPosition")
        muMVPMatrixLoc = GLES20.glGetUniformLocation(mProgramHandle, "uMVPMatrix")
        GlUtil.checkLocation(muMVPMatrixLoc, "uMVPMatrix")
        muColorLoc = GLES20.glGetUniformLocation(mProgramHandle, "uColor")
        GlUtil.checkLocation(muColorLoc, "uColor")
    }
}
