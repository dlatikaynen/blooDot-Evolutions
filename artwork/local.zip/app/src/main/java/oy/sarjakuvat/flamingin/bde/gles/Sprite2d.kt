package oy.sarjakuvat.flamingin.bde.gles

import android.opengl.Matrix

class Sprite2d(private val mDrawable: Drawable2dBase) {
    private val color: FloatArray = FloatArray(4)
    private var mTextureId: Int
    private var mAngle = 0f

    var scaleX = 0f
        private set

    var scaleY = 0f
        private set

    var positionX = 0f
        private set

    var positionY = 0f
        private set

    private val mModelViewMatrix: FloatArray
    private var mMatrixReady: Boolean
    private val mScratchMatrix = FloatArray(16)

    private fun recomputeMatrix() {
        val modelView = mModelViewMatrix
        Matrix.setIdentityM(modelView, 0)
        Matrix.translateM(modelView, 0, positionX, positionY, 0.0f)
        if (mAngle != 0.0f) {
            Matrix.rotateM(modelView, 0, mAngle, 0.0f, 0.0f, 1.0f)
        }
        Matrix.scaleM(modelView, 0, scaleX, scaleY, 1.0f)
        mMatrixReady = true
    }

    fun setScale(scaleX: Float, scaleY: Float) {
        this.scaleX = scaleX
        this.scaleY = scaleY
        mMatrixReady = false
    }

    var rotation: Float
        get() = mAngle
        set(angle) {
            var localAngle = angle
            while (localAngle >= 360.0f) {
                localAngle -= 360.0f
            }

            while (localAngle <= -360.0f) {
                localAngle += 360.0f
            }

            mAngle = localAngle
            mMatrixReady = false
        }

    fun setPosition(posX: Float, posY: Float) {
        positionX = posX
        positionY = posY
        mMatrixReady = false
    }

    private val modelViewMatrix: FloatArray
        get() {
            if (!mMatrixReady) {
                recomputeMatrix()
            }

            return mModelViewMatrix
        }

    fun setColor(red: Float, green: Float, blue: Float) {
        color[0] = red
        color[1] = green
        color[2] = blue
    }

    fun setTexture(textureId: Int) {
        mTextureId = textureId
    }

    fun draw(program: FlatShadedProgram, projectionMatrix: FloatArray?) {
        Matrix.multiplyMM(
            mScratchMatrix,
            0,
            projectionMatrix,
            0,
            modelViewMatrix,
            0
        )

        program.draw(
            mScratchMatrix,
            color,
            mDrawable.vertexArray,
            0,
            mDrawable.vertexCount,
            mDrawable.coordsPerVertex,
            mDrawable.vertexStride
        )
    }

    fun draw(program: Texture2dProgram, projectionMatrix: FloatArray?) {
        Matrix.multiplyMM(mScratchMatrix, 0, projectionMatrix, 0, modelViewMatrix, 0)
        program.draw(
            mScratchMatrix, mDrawable.vertexArray, 0,
            mDrawable.vertexCount, mDrawable.coordsPerVertex,
            mDrawable.vertexStride, GlUtil.IDENTITY_MATRIX, mDrawable.texCoordArray,
            mTextureId, mDrawable.texCoordStride
        )
    }

    override fun toString(): String {
        return "[Sprite is $mDrawable at $positionX,$positionY sized $scaleX,$scaleY rotated $mAngle colored ${color[0]},${color[1]},${color[2]}"
    }

    init {
        color[3] = 1.0f
        mTextureId = -1
        mModelViewMatrix = FloatArray(16)
        mMatrixReady = false
    }
}
