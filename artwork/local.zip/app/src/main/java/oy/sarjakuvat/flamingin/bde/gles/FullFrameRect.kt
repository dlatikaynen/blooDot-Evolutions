package oy.sarjakuvat.flamingin.bde.gles

class FullFrameRect(private var program: Texture2dProgram?) {
    private val mRectDrawable = Drawable2dBase(Drawable2dBase.Prefab.FULL_RECTANGLE)

    fun release(doEglCleanup: Boolean) {
        if (program != null) {
            if (doEglCleanup) {
                program!!.release()
            }

            program = null
        }
    }

    fun changeProgram(program: Texture2dProgram?) {
        program!!.release()
        this.program = program
    }

    fun createTextureObject(): Int {
        return program!!.createTextureObject()
    }

    fun drawFrame(textureId: Int, texMatrix: FloatArray?) {
        program!!.draw(
            GlUtil.IDENTITY_MATRIX,
            mRectDrawable.vertexArray,
            0,
            mRectDrawable.vertexCount,
            mRectDrawable.coordsPerVertex,
            mRectDrawable.vertexStride,
            texMatrix,
            mRectDrawable.texCoordArray,
            textureId,
            mRectDrawable.texCoordStride
        )
    }
}
