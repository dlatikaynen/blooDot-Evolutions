package oy.sarjakuvat.flamingin.bde.gles

import android.graphics.SurfaceTexture
import android.view.Surface
import java.lang.RuntimeException

class WindowSurface : EglSurfaceBase {
    private var mSurface: Surface? = null
    private var mReleaseSurface = false

    constructor(eglCore: EglCore?, surface: Surface?, releaseSurface: Boolean) : super(eglCore!!) {
        createWindowSurface(surface)
        mSurface = surface
        mReleaseSurface = releaseSurface
    }

    constructor(eglCore: EglCore?, surfaceTexture: SurfaceTexture?) : super(eglCore!!) {
        createWindowSurface(surfaceTexture)
    }

    fun recreate(newEglCore: EglCore) {
        if (mSurface == null) {
            throw RuntimeException("Attempt to recreate a null surface")
        }

        mEglCore = newEglCore
        createWindowSurface(mSurface)
    }

    fun release() {
        releaseEglSurface()
        if (mSurface != null) {
            if (mReleaseSurface) {
                mSurface!!.release()
            }

            mSurface = null
        }
    }
}
