package oy.sarjakuvat.flamingin.bde

import oy.sarjakuvat.flamingin.bde.gles.GpuSourceLoader.Companion.loadGpuSourceCode
import android.app.ListActivity
import android.os.Bundle
import android.widget.SimpleAdapter
import android.content.Intent
import android.view.View
import android.widget.ListView
import java.lang.RuntimeException
import java.util.ArrayList
import java.util.HashMap

/**
 * Main activity -- entry point from Launcher.
 */
class MainActivity : ListActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        listAdapter = SimpleAdapter(
            this,
            createActivityList(),
            android.R.layout.two_line_list_item,
            arrayOf(TITLE, DESCRIPTION),
            intArrayOf(android.R.id.text1, android.R.id.text2)
        )
    }

    /**
     * Creates the list of activities from the string arrays.
     */
    private fun createActivityList(): List<Map<String, Any?>> {
        val testList: MutableList<Map<String, Any?>> = ArrayList()
        for (test in TESTS) {
            val tmp: MutableMap<String, Any?> = HashMap()
            tmp[TITLE] = test[0]
            tmp[DESCRIPTION] = test[1]
            val intent = Intent()
            try {
                val cls = Class.forName("oy.sarjakuvat.flamingin.bde." + test[2])
                intent.setClass(this, cls)
                tmp[CLASS_NAME] = intent
            } catch (cnfe: ClassNotFoundException) {
                throw RuntimeException("Unable to find " + test[2], cnfe)
            }

            testList.add(tmp)
        }

        return testList
    }

    override fun onListItemClick(listView: ListView, view: View, position: Int, id: Long) {
        val map = listView.getItemAtPosition(position) as Map<*, *>
        val intent = map[CLASS_NAME] as Intent?
        startActivity(intent)
    }

    companion object {
        const val TAG = "bloo_dot_evolution"

        // map keys
        private const val TITLE = "title"
        private const val DESCRIPTION = "description"
        private const val CLASS_NAME = "class_name"

        /**
         * Each entry has three strings: the test title, the test description, and the name of
         * the activity class.
         */
        private val TESTS = arrayOf(
            arrayOf(
                "The blooDot Evolution Game",
                "Development Environment",
                "GameActivity"
            )
        )

        @JvmStatic
        val gpuSourceFlatVertexShader: String get() = loadGpuSourceCode(R.raw.flat_vertex_shader)

        @JvmStatic
        val gpuSourceFlatFragmentShader: String get() = loadGpuSourceCode(R.raw.flat_fragment_shader)

        @JvmStatic
        val gpuSourceTextureFragmentShader2d: String get() = loadGpuSourceCode(R.raw.texture_fragment_shader_2d)

        @JvmStatic
        val gpuSourceTextureFragmentShader2dBw: String get() = loadGpuSourceCode(R.raw.texture_fragment_shader_2d_bw)

        @JvmStatic
        val gpuSourceTextureFragmentShaderConvolutions: String get() = loadGpuSourceCode(R.raw.texture_fragment_shader_convolution)
        @JvmStatic

        val gpuSourceTextureFragmentShaderExternal: String get() = loadGpuSourceCode(R.raw.texture_fragment_shader_external)

        @JvmStatic
        val gpuSourceTextureFragmentShaderExternalBw: String get() = loadGpuSourceCode(R.raw.texture_fragment_shader_external_bw)

        @JvmStatic
        val gpuSourceTextureVertexShader: String get() = loadGpuSourceCode(R.raw.texture_vertex_shader)
    }
}
