package oy.sarjakuvat.flamingin.bde

import android.app.Activity
import android.os.Bundle
import android.widget.RadioButton
import android.widget.CheckBox
import android.widget.TextView
import android.icu.util.ULocale
import android.util.Log
import android.view.*
import oy.sarjakuvat.flamingin.bde.rendition.RenderThread
import java.lang.RuntimeException

/**
 * The purpose of the feature is to allow games to render at 720p or 1080p to get good
 * performance on displays with a large number of pixels.  It's easier (and more fun) to
 * see the effects when we crank the resolution way down.  Normally the resolution would
 * be fixed, perhaps with minor tweaks (e.g. letterboxing via AspectFrameLayout) to match
 * the device aspect ratio, but here we make it variable to match the display window.
 */
class GameActivity : Activity(), SurfaceHolder.Callback, Choreographer.FrameCallback {
    private var mSelectedSize = 0
    private var mFullViewWidth = 0
    private var mFullViewHeight = 0
    private lateinit var mWindowWidthHeight: Array<IntArray>
    private var mFlatShadingChecked = false

    // Rendering code runs on this thread.  The thread's life span is tied to the Surface.
    private var mRenderThread: RenderThread? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        Log.d(TAG, "GameActivity: onCreate")
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_game)
        mSelectedSize = SURFACE_SIZE_FULL
        mFullViewHeight = 512
        mFullViewWidth = mFullViewHeight // want actual view size, but it's not avail
        mWindowWidthHeight = Array(SURFACE_DIM.size) { IntArray(2) }
        updateControls()
        val sv = findViewById<SurfaceView>(R.id.game_surfaceView)
        sv.holder.addCallback(this)
    }

    override fun onPause() {
        super.onPause()

        // If the callback was posted, remove it.  This stops the notifications.  Ideally we
        // would send a message to the thread letting it know, so when it wakes up it can
        // reset its notion of when the previous Choreographer event arrived.
        Log.d(TAG, "onPause unhooking choreographer")
        Choreographer.getInstance().removeFrameCallback(this)
    }

    override fun onResume() {
        super.onResume()

        // If we already have a Surface, we just need to resume the frame notifications.
        if (mRenderThread != null) {
            Log.d(TAG, "onResume re-hooking choreographer")
            Choreographer.getInstance().postFrameCallback(this)
        }
    }

    override fun surfaceCreated(holder: SurfaceHolder) {
        Log.d(TAG, "surfaceCreated holder=$holder")

        // Grab the view's width.  It's not available before now.
        val size = holder.surfaceFrame
        mFullViewWidth = size.width()
        mFullViewHeight = size.height()

        // Configure our fixed-size values.  We want to configure it so that the narrowest
        // dimension (e.g. width when device is in portrait orientation) is equal to the
        // value in SURFACE_DIM, and the other dimension is sized to maintain the same
        // aspect ratio.
        val windowAspect = mFullViewHeight.toFloat() / mFullViewWidth.toFloat()
        for (i in SURFACE_DIM.indices) {
            when {
                i == SURFACE_SIZE_FULL -> {
                    // special-case for full size
                    mWindowWidthHeight[i][0] = mFullViewWidth
                    mWindowWidthHeight[i][1] = mFullViewHeight
                }
                mFullViewWidth < mFullViewHeight -> {
                    // portrait
                    mWindowWidthHeight[i][0] = SURFACE_DIM[i]
                    mWindowWidthHeight[i][1] = (SURFACE_DIM[i] * windowAspect).toInt()
                }
                else -> {
                    // landscape
                    mWindowWidthHeight[i][0] = (SURFACE_DIM[i] / windowAspect).toInt()
                    mWindowWidthHeight[i][1] = SURFACE_DIM[i]
                }
            }
        }

        // Some controls include text based on the view dimensions, so update now
        updateControls()
        val sv = findViewById<SurfaceView>(R.id.game_surfaceView)
        mRenderThread = RenderThread(sv.holder)
        mRenderThread!!.name = "blooDot Evolution OpenGL ES renderer"
        mRenderThread!!.start()
        mRenderThread!!.waitUntilReady()
        val rh = mRenderThread!!.handler
        if (rh != null) {
            rh.sendSetFlatShading(mFlatShadingChecked)
            rh.sendSurfaceCreated()
        }

        // start the draw events
        Choreographer.getInstance().postFrameCallback(this)
    }

    override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
        Log.d(
            TAG, "surfaceChanged fmt=" + format + " size=" + width + "x" + height +
                    " holder=" + holder
        )

        val rh = mRenderThread!!.handler
        rh?.sendSurfaceChanged(width, height)
    }

    override fun surfaceDestroyed(holder: SurfaceHolder) {
        Log.d(TAG, "surfaceDestroyed holder=$holder")

        // We need to wait for the render thread to shut down before continuing because we
        // don't want the Surface to disappear out from under it mid-render.  The frame
        // notifications will have been stopped back in onPause(), but there might have
        // been one in progress.
        val rh = mRenderThread!!.handler
        if (rh != null) {
            rh.sendShutdown()
            try {
                mRenderThread!!.join()
            } catch (ie: InterruptedException) {
                // not expected
                throw RuntimeException("join was interrupted", ie)
            }
        }

        mRenderThread = null
        Log.d(TAG, "surfaceDestroyed complete")
    }

    /*
     * Choreographer callback, called near vsync.
     *
     * @see android.view.Choreographer.FrameCallback#doFrame(long)
     */
    override fun doFrame(frameTimeNanos: Long) {
        val rh = mRenderThread!!.handler
        if (rh != null) {
            Choreographer.getInstance().postFrameCallback(this)
            rh.sendDoFrame(frameTimeNanos)
        }
    }

    /**
     * onClick handler for radio buttons.
     */
    fun onRadioButtonClicked(view: View) {
        val newSize: Int
        val rb = view as RadioButton
        if (!rb.isChecked) {
            Log.d(TAG, "Got click on non-checked radio button")
            return
        }
        val resId = rb.id
        newSize = when (resId) {
            R.id.surfaceSizeTiny_radio -> {
                SURFACE_SIZE_TINY
            }
            R.id.surfaceSizeSmall_radio -> {
                SURFACE_SIZE_SMALL
            }
            R.id.surfaceSizeMedium_radio -> {
                SURFACE_SIZE_MEDIUM
            }
            R.id.surfaceSizeFull_radio -> {
                SURFACE_SIZE_FULL
            }
            else -> {
                throw RuntimeException("Click from unknown id " + rb.id)
            }
        }
        mSelectedSize = newSize
        val wh = mWindowWidthHeight[newSize]

        // Update the Surface size.  This causes a "surface changed" event, but does not
        // destroy and re-create the Surface
        val sv = findViewById<SurfaceView>(R.id.game_surfaceView)
        val sh = sv.holder
        Log.d(TAG, "setting size to " + wh[0] + "x" + wh[1])
        sh.setFixedSize(wh[0], wh[1])
    }

    @Suppress("UNUSED_PARAMETER")
    fun onFlatShadingClicked(view: View) {
        val cb = findViewById<CheckBox>(R.id.flatShading_checkbox)
        mFlatShadingChecked = cb.isChecked
        val rh = mRenderThread!!.handler
        rh?.sendSetFlatShading(mFlatShadingChecked)
    }

    /**
     * Updates the on-screen controls to reflect the current state of the app.
     */
    private fun updateControls() {
        configureRadioButton(R.id.surfaceSizeTiny_radio, SURFACE_SIZE_TINY)
        configureRadioButton(R.id.surfaceSizeSmall_radio, SURFACE_SIZE_SMALL)
        configureRadioButton(R.id.surfaceSizeMedium_radio, SURFACE_SIZE_MEDIUM)
        configureRadioButton(R.id.surfaceSizeFull_radio, SURFACE_SIZE_FULL)
        val tv = findViewById<TextView>(R.id.viewSizeValue_text)
        tv.text = String.format("%dx%d", mFullViewWidth, mFullViewHeight)
        val cb = findViewById<CheckBox>(R.id.flatShading_checkbox)
        cb.isChecked = mFlatShadingChecked
    }

    /**
     * Generates the radio button text.
     */
    private fun configureRadioButton(id: Int, index: Int) {
        val rb: RadioButton = findViewById(id)
        rb.isChecked = mSelectedSize == index
        rb.text = String.format(
            ULocale.getDefault().toLocale(), "%s (%dx%d)",
            SURFACE_LABEL[index],
            mWindowWidthHeight[index][0],
            mWindowWidthHeight[index][1]
        )
    }

    companion object {
        const val TAG = MainActivity.TAG
        private const val SURFACE_SIZE_TINY = 0
        private const val SURFACE_SIZE_SMALL = 1
        private const val SURFACE_SIZE_MEDIUM = 2
        private const val SURFACE_SIZE_FULL = 3
        private val SURFACE_DIM = intArrayOf(64, 240, 480, -1)
        private val SURFACE_LABEL = arrayOf(
            "tiny", "small", "medium", "full"
        )
    }
}
