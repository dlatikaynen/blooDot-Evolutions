package oy.sarjakuvat.flamingin.bde.rendition.offscreen

import android.graphics.Canvas
import oy.sarjakuvat.flamingin.bde.rendition.offscreen.TilePainterBase

abstract class BlobPainterBase : TilePainterBase() {
    abstract fun paintBlobTile(paintTo: Canvas, primeIndex: Int)
}
